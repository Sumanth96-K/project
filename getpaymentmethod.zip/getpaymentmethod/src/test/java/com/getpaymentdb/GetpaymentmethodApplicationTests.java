package com.getpaymentdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetpaymentmethodApplicationTests {

	@Test
	void contextLoads() {
	}

}
