package com.getpaymentdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetpaymentmethodApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetpaymentmethodApplication.class, args);
	}

}
